"""
fetch_data.py
--------------
Pulls obesity / weight-management clinical trial records from the
ClinicalTrials.gov API v2 (https://clinicaltrials.gov/data-api/api)
and writes a clean CSV to data/trials_raw.csv.

Run locally (needs internet access):
    python fetch_data.py

No API key required. The v2 API is public and free.
"""

import requests
import pandas as pd
import time
import json
import os

BASE_URL = "https://clinicaltrials.gov/api/v2/studies"

# Search terms covering the weight-loss / obesity / metabolic space,
# including GLP-1 drug class trials (semaglutide, tirzepatide, liraglutide,
# danuglipron, etc.)
SEARCH_EXPR = (
    '(obesity OR "weight loss" OR "weight management" OR "GLP-1" '
    'OR semaglutide OR tirzepatide OR liraglutide OR danuglipron)'
)

FIELDS = [
    "NCTId",
    "BriefTitle",
    "OverallStatus",
    "Phase",
    "StudyType",
    "EnrollmentCount",
    "EnrollmentType",
    "StartDate",
    "PrimaryCompletionDate",
    "CompletionDate",
    "LeadSponsorName",
    "LeadSponsorClass",
    "InterventionName",
    "InterventionType",
    "DesignAllocation",
    "DesignInterventionModel",
    "DesignMasking",
    "DesignPrimaryPurpose",
    "Condition",
    "WhyStopped",
]


def fetch_all_studies(page_size: int = 100, max_pages: int = 50):
    """Paginate through the ClinicalTrials.gov v2 API and collect studies."""
    all_studies = []
    params = {
        "query.term": SEARCH_EXPR,
        "fields": ",".join(FIELDS),
        "pageSize": page_size,
        "format": "json",
    }

    page = 0
    next_token = None
    while page < max_pages:
        if next_token:
            params["pageToken"] = next_token

        resp = requests.get(BASE_URL, params=params, timeout=30)
        resp.raise_for_status()
        payload = resp.json()

        studies = payload.get("studies", [])
        all_studies.extend(studies)

        next_token = payload.get("nextPageToken")
        page += 1
        print(f"Fetched page {page}, running total: {len(all_studies)} studies")

        if not next_token:
            break
        time.sleep(0.3)  # be polite to the API

    return all_studies


def flatten_study(study: dict) -> dict:
    """Pull the fields we care about out of the nested v2 JSON structure."""
    proto = study.get("protocolSection", {})
    ident = proto.get("identificationModule", {})
    status = proto.get("statusModule", {})
    design = proto.get("designModule", {})
    sponsor = proto.get("sponsorCollaboratorsModule", {})
    arms = proto.get("armsInterventionsModule", {})
    conditions = proto.get("conditionsModule", {})

    interventions = arms.get("interventions", [])
    intervention_names = "; ".join(i.get("name", "") for i in interventions)
    intervention_types = "; ".join(i.get("type", "") for i in interventions)

    design_info = design.get("designInfo", {})

    return {
        "nct_id": ident.get("nctId"),
        "brief_title": ident.get("briefTitle"),
        "overall_status": status.get("overallStatus"),
        "phase": ";".join(design.get("phases", [])) if design.get("phases") else None,
        "study_type": design.get("studyType"),
        "enrollment_count": design.get("enrollmentInfo", {}).get("count"),
        "enrollment_type": design.get("enrollmentInfo", {}).get("type"),
        "start_date": status.get("startDateStruct", {}).get("date"),
        "primary_completion_date": status.get("primaryCompletionDateStruct", {}).get("date"),
        "completion_date": status.get("completionDateStruct", {}).get("date"),
        "lead_sponsor_name": sponsor.get("leadSponsor", {}).get("name"),
        "lead_sponsor_class": sponsor.get("leadSponsor", {}).get("class"),
        "intervention_names": intervention_names,
        "intervention_types": intervention_types,
        "allocation": design_info.get("allocation"),
        "intervention_model": design_info.get("interventionModel"),
        "masking": design_info.get("maskingInfo", {}).get("masking"),
        "primary_purpose": design_info.get("primaryPurpose"),
        "conditions": "; ".join(conditions.get("conditions", [])),
        "why_stopped": status.get("whyStopped"),
    }


def main():
    print("Querying ClinicalTrials.gov API v2 for obesity/weight-loss trials...")
    raw_studies = fetch_all_studies()
    rows = [flatten_study(s) for s in raw_studies]
    df = pd.DataFrame(rows)

    out_path = os.path.join(os.path.dirname(__file__), "trials_raw.csv")
    df.to_csv(out_path, index=False)
    print(f"Saved {len(df)} trials to {out_path}")


if __name__ == "__main__":
    main()
