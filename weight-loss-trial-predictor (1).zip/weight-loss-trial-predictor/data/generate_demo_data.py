"""
generate_demo_data.py
----------------------
Generates a realistic *synthetic* dataset of obesity/weight-loss clinical
trials, modeled on the real structure and distributions you'd see from
ClinicalTrials.gov (phase, sponsor class, drug class, enrollment size, etc).

Why this exists: ClinicalTrials.gov isn't reachable from every sandboxed
dev environment (corporate firewalls, CI runners, etc). This script lets
you build/test/demo the full modeling pipeline immediately. Swap in
fetch_data.py's real output whenever you have live internet access --
the schema is identical, so nothing downstream changes.
"""

import numpy as np
import pandas as pd
import os

RNG = np.random.default_rng(42)

N_TRIALS = 900

DRUG_CLASSES = ["GLP-1 agonist", "GIP/GLP-1 dual agonist", "Behavioral/lifestyle",
                "Bariatric device", "Other pharmacological"]
DRUG_CLASS_WEIGHTS = [0.32, 0.14, 0.28, 0.08, 0.18]

PHASES = ["Phase 1", "Phase 2", "Phase 3", "Phase 4", "Not Applicable"]
PHASE_WEIGHTS = [0.12, 0.30, 0.22, 0.10, 0.26]

SPONSOR_CLASS = ["INDUSTRY", "NIH", "OTHER", "ACADEMIC"]
SPONSOR_WEIGHTS = [0.55, 0.08, 0.22, 0.15]

MASKING = ["None (Open Label)", "Single", "Double", "Triple", "Quadruple"]
MASKING_WEIGHTS = [0.30, 0.10, 0.30, 0.10, 0.20]

ALLOCATION = ["Randomized", "Non-Randomized"]
ALLOCATION_WEIGHTS = [0.78, 0.22]


def sample_enrollment(phase):
    if phase == "Phase 1":
        return int(RNG.gamma(2.0, 20))
    if phase == "Phase 2":
        return int(RNG.gamma(3.0, 60))
    if phase == "Phase 3":
        return int(RNG.gamma(4.0, 250))
    if phase == "Phase 4":
        return int(RNG.gamma(3.0, 150))
    return int(RNG.gamma(2.5, 80))


def sample_duration_weeks(phase, drug_class):
    base = {
        "Phase 1": 12, "Phase 2": 26, "Phase 3": 68, "Phase 4": 52, "Not Applicable": 20
    }[phase]
    if drug_class in ("GLP-1 agonist", "GIP/GLP-1 dual agonist"):
        base += 12  # obesity drug trials tend to run long to capture durable weight loss
    return max(4, int(RNG.normal(base, base * 0.3)))


def true_dropout_and_completion(row):
    """
    Build a *ground truth* generating process with realistic structure so
    the ML models have real signal to find (not pure noise):
      - Longer trials -> more dropout
      - Open-label / non-randomized -> more dropout (less commitment structure)
      - GLP-1 trials -> historically higher discontinuation due to GI side effects
      - Small industry Phase 3 trials with double-blind masking -> best completion
    """
    dropout = 0.08  # baseline
    dropout += 0.0025 * row["duration_weeks"]
    if row["masking"] == "None (Open Label)":
        dropout += 0.07
    if row["allocation"] == "Non-Randomized":
        dropout += 0.05
    if row["drug_class"] in ("GLP-1 agonist", "GIP/GLP-1 dual agonist"):
        dropout += 0.06  # GI side effects (nausea, etc.) drive discontinuation
    if row["phase"] == "Phase 1":
        dropout -= 0.03
    if row["sponsor_class"] == "INDUSTRY":
        dropout -= 0.02  # more resourced trial ops
    if row["enrollment_count"] > 500:
        dropout += 0.03  # harder to retain in large multi-site trials

    dropout += RNG.normal(0, 0.05)
    dropout = float(np.clip(dropout, 0.01, 0.85))

    # Completion is driven mainly by dropout, with a small amount of
    # independent trial-level risk (funding pulled, safety signal, etc.)
    completion_prob = np.clip(1 - 1.4 * dropout - RNG.normal(0, 0.025), 0.02, 0.98)
    completed = RNG.random() < completion_prob

    return dropout, completed


def main():
    drug_class = RNG.choice(DRUG_CLASSES, size=N_TRIALS, p=DRUG_CLASS_WEIGHTS)
    phase = RNG.choice(PHASES, size=N_TRIALS, p=PHASE_WEIGHTS)
    sponsor_class = RNG.choice(SPONSOR_CLASS, size=N_TRIALS, p=SPONSOR_WEIGHTS)
    masking = RNG.choice(MASKING, size=N_TRIALS, p=MASKING_WEIGHTS)
    allocation = RNG.choice(ALLOCATION, size=N_TRIALS, p=ALLOCATION_WEIGHTS)

    df = pd.DataFrame({
        "nct_id": [f"NCT{RNG.integers(10000000, 99999999)}" for _ in range(N_TRIALS)],
        "drug_class": drug_class,
        "phase": phase,
        "sponsor_class": sponsor_class,
        "masking": masking,
        "allocation": allocation,
    })

    df["enrollment_count"] = df["phase"].apply(sample_enrollment).clip(lower=5)
    df["duration_weeks"] = df.apply(
        lambda r: sample_duration_weeks(r["phase"], r["drug_class"]), axis=1
    )

    dropouts, completions = [], []
    for _, row in df.iterrows():
        d, c = true_dropout_and_completion(row)
        dropouts.append(round(d, 3))
        completions.append(c)

    df["dropout_rate"] = dropouts
    df["completed"] = completions
    df["overall_status"] = df["completed"].map(
        lambda c: "COMPLETED" if c else RNG.choice(
            ["TERMINATED", "WITHDRAWN", "SUSPENDED"], p=[0.6, 0.3, 0.1]
        )
    )

    out_path = os.path.join(os.path.dirname(__file__), "trials_demo.csv")
    df.to_csv(out_path, index=False)
    print(f"Generated {len(df)} synthetic trials -> {out_path}")
    print(df.head())


if __name__ == "__main__":
    main()
