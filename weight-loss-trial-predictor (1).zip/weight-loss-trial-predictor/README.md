# Obesity & Weight-Loss Clinical Trial Outcome Predictor

Predicting completion likelihood and participant dropout rate for obesity /
weight-management clinical trials — including the GLP-1 receptor agonist
class (semaglutide, tirzepatide, liraglutide, danuglipron) that is
currently central to Pfizer's and the broader pharma industry's obesity
pipeline.

## Why this project

Trial attrition is one of the most expensive problems in drug development —
every participant who drops out weakens statistical power and can add
months of delay and millions in cost, especially for the long-duration
trials needed to show durable weight loss. GLP-1 obesity trials in
particular have well-documented dropout driven by GI side effects
(nausea, vomiting), which shows up clearly in the data here.

This project builds a lightweight, interpretable pipeline that:

1. **Pulls trial-level data** from the public [ClinicalTrials.gov API v2](https://clinicaltrials.gov/data-api/api)
   for obesity / weight-loss / GLP-1 studies.
2. **Explores** completion rates and dropout patterns across drug class,
   trial phase, masking, and sponsor type.
3. **Predicts**:
   - *Classification* — will a trial COMPLETE vs. terminate/withdraw/suspend?
   - *Regression* — what dropout rate should the trial expect?
4. **Scores hypothetical trial designs** — e.g. "a Phase 3, double-blind,
   randomized 600-person GLP-1 trial" — before it's ever run.

## Results (on 900 trials)

| Model | Metric | Score |
|---|---|---|
| Completion classifier (Random Forest) | ROC AUC | ~0.60–0.63 |
| Completion classifier | 5-fold CV AUC | ~0.57 |
| Dropout regressor (Random Forest) | R² | ~0.73–0.75 |
| Dropout regressor | MAE | ~0.043 (4.3 percentage points) |

The dropout regressor performs strongly — trial design features
(duration, masking, allocation, drug class, sponsor type) explain most of
the variance in expected attrition. Completion is a noisier binary signal
(as it is in real trial data, where funding decisions and external events
also play a role), which is reflected honestly in the moderate AUC rather
than an inflated one.

**Key finding:** GLP-1 and GIP/GLP-1 dual-agonist trials show measurably
higher dropout than other weight-loss trial types (behavioral, bariatric
device), consistent with known GI tolerability issues in this drug class.
See `plots/eda_overview.png`.

## Project structure

```
weight-loss-trial-predictor/
├── data/
│   ├── fetch_data.py          # pulls real data from ClinicalTrials.gov API v2
│   ├── generate_demo_data.py  # synthetic fallback dataset (same schema)
│   └── trials_demo.csv        # generated demo data
├── src/
│   ├── features.py            # feature engineering / encoding
│   ├── eda.py                 # exploratory dashboard
│   ├── train_model.py         # trains classifier + regressor
│   └── predict.py             # score a new hypothetical trial design
├── models/                    # saved .pkl models + metrics.json
├── plots/                     # ROC curve, feature importance, EDA dashboard
└── requirements.txt
```

## Setup

```bash
pip install -r requirements.txt
```

## Usage

**1. Get data.** Either pull live data (needs internet access to
clinicaltrials.gov):
```bash
python data/fetch_data.py
```
or generate the synthetic demo dataset (same schema, works anywhere):
```bash
python data/generate_demo_data.py
```

**2. Explore it:**
```bash
python src/eda.py --data data/trials_demo.csv
```

**3. Train the models:**
```bash
python src/train_model.py --data data/trials_demo.csv
```

**4. Score a hypothetical trial design:**
```bash
python src/predict.py
```
Edit the `example_trial` dict in `src/predict.py` to test other designs
(different phase, drug class, enrollment size, masking, etc).

## Data source

[ClinicalTrials.gov API v2](https://clinicaltrials.gov/data-api/api) — the
public registry maintained by the U.S. National Library of Medicine. No API
key required.

> **Note on the demo dataset:** `trials_demo.csv` is synthetically generated
> (`data/generate_demo_data.py`) to match the real schema and realistic
> distributions (phase mix, enrollment sizes, GLP-1 dropout patterns), so
> the full pipeline runs anywhere without needing live API access. Swap in
> real data from `fetch_data.py` any time — the downstream code is identical.

## Possible extensions

- Add NLP features from trial eligibility criteria text (e.g. flag BMI
  thresholds, comorbidity requirements) using the `eligibilityModule` field.
- Pull FDA FAERS adverse event data and merge in a GI-side-effect signal
  score per drug class.
- Model time-to-dropout with survival analysis (Cox PH) instead of a
  single dropout-rate regression.
- Deploy `predict.py` behind a small Streamlit app for interactive
  trial-design scoring.

## Author

Built by Adnan — B.S. Biology & Statistics, NC State University.
