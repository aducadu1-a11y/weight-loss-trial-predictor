"""
train_model.py
----------------
Trains two models on obesity/weight-loss clinical trial data:

1. Classifier  -> predicts whether a trial will COMPLETE vs.
                  terminate/withdraw/suspend (binary).
2. Regressor   -> predicts the trial's participant dropout rate (continuous).

Usage:
    python src/train_model.py --data data/trials_demo.csv
"""

import argparse
import os
import sys
import joblib
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.metrics import (
    roc_auc_score, accuracy_score, f1_score, confusion_matrix,
    mean_absolute_error, r2_score, RocCurveDisplay
)

sys.path.append(os.path.dirname(__file__))
from features import load_trials, build_features


def train_classifier(X_train, X_test, y_train, y_test, feature_names, plots_dir):
    clf = RandomForestClassifier(
        n_estimators=400, max_depth=8, min_samples_leaf=5,
        random_state=42, class_weight="balanced", n_jobs=-1
    )
    clf.fit(X_train, y_train)

    y_pred = clf.predict(X_test)
    y_proba = clf.predict_proba(X_test)[:, 1]

    acc = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    auc = roc_auc_score(y_test, y_proba)
    cv_auc = cross_val_score(clf, pd.concat([X_train, X_test]),
                              pd.concat([y_train, y_test]), cv=5, scoring="roc_auc")

    print("\n=== Classifier: Trial Completion Prediction ===")
    print(f"Accuracy : {acc:.3f}")
    print(f"F1 score : {f1:.3f}")
    print(f"ROC AUC  : {auc:.3f}")
    print(f"5-fold CV ROC AUC: {cv_auc.mean():.3f} (+/- {cv_auc.std():.3f})")

    cm = confusion_matrix(y_test, y_pred)
    print("Confusion matrix:\n", cm)

    # ROC curve plot
    fig, ax = plt.subplots(figsize=(6, 5))
    RocCurveDisplay.from_predictions(y_test, y_proba, ax=ax)
    ax.set_title("ROC Curve — Trial Completion Classifier")
    fig.tight_layout()
    fig.savefig(os.path.join(plots_dir, "roc_curve.png"), dpi=150)
    plt.close(fig)

    # Feature importance plot
    importances = pd.Series(clf.feature_importances_, index=feature_names)
    importances = importances.sort_values(ascending=True).tail(15)
    fig, ax = plt.subplots(figsize=(7, 6))
    importances.plot(kind="barh", ax=ax, color="#2E86AB")
    ax.set_title("Top 15 Feature Importances — Completion Model")
    ax.set_xlabel("Importance")
    fig.tight_layout()
    fig.savefig(os.path.join(plots_dir, "feature_importance_classifier.png"), dpi=150)
    plt.close(fig)

    return clf, {"accuracy": acc, "f1": f1, "roc_auc": auc, "cv_auc_mean": cv_auc.mean()}


def train_regressor(X_train, X_test, y_train, y_test, feature_names, plots_dir):
    reg = RandomForestRegressor(
        n_estimators=400, max_depth=8, min_samples_leaf=5,
        random_state=42, n_jobs=-1
    )
    reg.fit(X_train, y_train)

    y_pred = reg.predict(X_test)
    mae = mean_absolute_error(y_test, y_pred)
    r2 = r2_score(y_test, y_pred)
    cv_r2 = cross_val_score(reg, pd.concat([X_train, X_test]),
                             pd.concat([y_train, y_test]), cv=5, scoring="r2")

    print("\n=== Regressor: Dropout Rate Prediction ===")
    print(f"MAE      : {mae:.4f}")
    print(f"R^2      : {r2:.3f}")
    print(f"5-fold CV R^2: {cv_r2.mean():.3f} (+/- {cv_r2.std():.3f})")

    # Predicted vs actual plot
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(y_test, y_pred, alpha=0.5, color="#A23B72")
    lims = [0, max(y_test.max(), y_pred.max()) * 1.05]
    ax.plot(lims, lims, "k--", linewidth=1)
    ax.set_xlabel("Actual dropout rate")
    ax.set_ylabel("Predicted dropout rate")
    ax.set_title("Predicted vs. Actual Dropout Rate")
    fig.tight_layout()
    fig.savefig(os.path.join(plots_dir, "dropout_pred_vs_actual.png"), dpi=150)
    plt.close(fig)

    return reg, {"mae": mae, "r2": r2, "cv_r2_mean": cv_r2.mean()}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data/trials_demo.csv",
                         help="Path to trials CSV (from fetch_data.py or generate_demo_data.py)")
    parser.add_argument("--outdir", default="models")
    parser.add_argument("--plotsdir", default="plots")
    args = parser.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    os.makedirs(args.plotsdir, exist_ok=True)

    df = load_trials(args.data)
    X, y_class, y_reg = build_features(df)
    feature_names = X.columns.tolist()

    X_train, X_test, yc_train, yc_test, yr_train, yr_test = train_test_split(
        X, y_class, y_reg, test_size=0.2, random_state=42, stratify=y_class
    )

    clf, clf_metrics = train_classifier(X_train, X_test, yc_train, yc_test,
                                         feature_names, args.plotsdir)
    reg, reg_metrics = train_regressor(X_train, X_test, yr_train, yr_test,
                                        feature_names, args.plotsdir)

    joblib.dump({"model": clf, "feature_names": feature_names},
                os.path.join(args.outdir, "completion_classifier.pkl"))
    joblib.dump({"model": reg, "feature_names": feature_names},
                os.path.join(args.outdir, "dropout_regressor.pkl"))

    metrics = {"classifier": clf_metrics, "regressor": reg_metrics}
    pd.Series(metrics).to_json(os.path.join(args.outdir, "metrics.json"), indent=2)

    print(f"\nModels saved to {args.outdir}/")
    print(f"Plots saved to {args.plotsdir}/")


if __name__ == "__main__":
    main()
