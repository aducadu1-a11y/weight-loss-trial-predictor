"""
features.py
------------
Turns raw trial records (from fetch_data.py OR generate_demo_data.py --
same schema) into a model-ready feature matrix.
"""

import pandas as pd


CATEGORICAL_COLS = ["drug_class", "phase", "sponsor_class", "masking", "allocation"]
NUMERIC_COLS = ["enrollment_count", "duration_weeks"]


def load_trials(path: str) -> pd.DataFrame:
    df = pd.read_csv(path)
    return df


def build_features(df: pd.DataFrame) -> tuple[pd.DataFrame, pd.Series, pd.Series]:
    """
    Returns:
        X : feature matrix (one-hot encoded categoricals + numeric cols)
        y_class : binary target, 1 = trial completed, 0 = not completed
        y_reg   : continuous target, dropout_rate
    """
    df = df.copy()

    # Guard against missing values in a light-touch way (median/mode impute)
    for col in NUMERIC_COLS:
        df[col] = df[col].fillna(df[col].median())
    for col in CATEGORICAL_COLS:
        df[col] = df[col].fillna("Unknown")

    X_cat = pd.get_dummies(df[CATEGORICAL_COLS], drop_first=False)
    X_num = df[NUMERIC_COLS]
    X = pd.concat([X_num, X_cat], axis=1)

    y_class = df["completed"].astype(int) if "completed" in df.columns else None
    y_reg = df["dropout_rate"] if "dropout_rate" in df.columns else None

    return X, y_class, y_reg
