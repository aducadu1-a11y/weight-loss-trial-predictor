"""
predict.py
-----------
Loads the trained models and scores a new hypothetical trial design.
Useful for "what-if" questions like:
    "If I design a Phase 3, double-blind, randomized GLP-1 trial with
     600 participants over 68 weeks, what's the predicted completion
     likelihood and dropout rate?"

Usage:
    python src/predict.py
(edit the `example_trial` dict below to test other designs)
"""

import os
import sys
import joblib
import pandas as pd

sys.path.append(os.path.dirname(__file__))
from features import CATEGORICAL_COLS, NUMERIC_COLS


def build_single_row(trial: dict, feature_names: list) -> pd.DataFrame:
    row = pd.DataFrame([trial])
    row_cat = pd.get_dummies(row[CATEGORICAL_COLS])
    row_num = row[NUMERIC_COLS]
    row_full = pd.concat([row_num, row_cat], axis=1)
    # align to training feature columns (fills any missing dummy cols with 0)
    row_full = row_full.reindex(columns=feature_names, fill_value=0)
    return row_full


def main():
    models_dir = os.path.join(os.path.dirname(__file__), "..", "models")
    clf_bundle = joblib.load(os.path.join(models_dir, "completion_classifier.pkl"))
    reg_bundle = joblib.load(os.path.join(models_dir, "dropout_regressor.pkl"))

    clf, feature_names = clf_bundle["model"], clf_bundle["feature_names"]
    reg = reg_bundle["model"]

    example_trial = {
        "drug_class": "GLP-1 agonist",
        "phase": "Phase 3",
        "sponsor_class": "INDUSTRY",
        "masking": "Double",
        "allocation": "Randomized",
        "enrollment_count": 600,
        "duration_weeks": 68,
    }

    X_new = build_single_row(example_trial, feature_names)

    completion_prob = clf.predict_proba(X_new)[0, 1]
    predicted_dropout = reg.predict(X_new)[0]

    print("Trial design:")
    for k, v in example_trial.items():
        print(f"  {k}: {v}")
    print(f"\nPredicted completion probability: {completion_prob:.1%}")
    print(f"Predicted dropout rate: {predicted_dropout:.1%}")


if __name__ == "__main__":
    main()
