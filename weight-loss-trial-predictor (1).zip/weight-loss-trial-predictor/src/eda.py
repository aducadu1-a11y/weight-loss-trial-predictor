"""
eda.py
-------
Quick exploratory dashboard on the obesity/weight-loss trial dataset.
Produces plots/eda_overview.png for the README.
"""

import argparse
import os
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

sns.set_style("whitegrid")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--data", default="data/trials_demo.csv")
    parser.add_argument("--plotsdir", default="plots")
    args = parser.parse_args()
    os.makedirs(args.plotsdir, exist_ok=True)

    df = pd.read_csv(args.data)

    fig, axes = plt.subplots(2, 2, figsize=(13, 10))

    # 1. Completion rate by drug class
    comp_by_class = df.groupby("drug_class")["completed"].mean().sort_values()
    comp_by_class.plot(kind="barh", ax=axes[0, 0], color="#2E86AB")
    axes[0, 0].set_title("Trial Completion Rate by Drug Class")
    axes[0, 0].set_xlabel("Completion rate")

    # 2. Dropout rate distribution by phase
    order = ["Phase 1", "Phase 2", "Phase 3", "Phase 4", "Not Applicable"]
    sns.boxplot(data=df, x="phase", y="dropout_rate", order=order, ax=axes[0, 1],
                palette="viridis")
    axes[0, 1].set_title("Dropout Rate Distribution by Trial Phase")
    axes[0, 1].tick_params(axis="x", rotation=30)

    # 3. Enrollment vs dropout rate, colored by drug class
    for dc, sub in df.groupby("drug_class"):
        axes[1, 0].scatter(sub["enrollment_count"], sub["dropout_rate"],
                            label=dc, alpha=0.5, s=18)
    axes[1, 0].set_xscale("log")
    axes[1, 0].set_xlabel("Enrollment (log scale)")
    axes[1, 0].set_ylabel("Dropout rate")
    axes[1, 0].set_title("Enrollment Size vs. Dropout Rate")
    axes[1, 0].legend(fontsize=7, loc="upper right")

    # 4. GLP-1 vs non-GLP-1 dropout comparison
    df["is_glp1"] = df["drug_class"].isin(["GLP-1 agonist", "GIP/GLP-1 dual agonist"])
    sns.violinplot(data=df, x="is_glp1", y="dropout_rate", ax=axes[1, 1],
                    palette=["#A9A9A9", "#A23B72"])
    axes[1, 1].set_xticklabels(["Other", "GLP-1 / GIP-GLP-1"])
    axes[1, 1].set_title("Dropout Rate: GLP-1 Drug Class vs. Others")
    axes[1, 1].set_xlabel("")

    fig.suptitle("Obesity / Weight-Loss Clinical Trials — Overview", fontsize=15, y=1.02)
    fig.tight_layout()
    fig.savefig(os.path.join(args.plotsdir, "eda_overview.png"), dpi=150, bbox_inches="tight")
    print(f"Saved {args.plotsdir}/eda_overview.png")

    print("\nSummary stats:")
    print(f"Total trials: {len(df)}")
    print(f"Overall completion rate: {df['completed'].mean():.1%}")
    print(f"Mean dropout rate: {df['dropout_rate'].mean():.1%}")
    print("\nCompletion rate by drug class:")
    print(comp_by_class.to_string())


if __name__ == "__main__":
    main()
